#include <avr/io.h>

// Led D1 = 13 = PB7
// Led D2 = 12 = PB6
// Led D3 = 11 = PB5
// Led D4 = 10 = PB4
// Knop S1 = A1 = PF1
// Knop S2 = A2 = PF2
// Knop S3 = A3 = PF3

static void init(void)
{
	// Led D1 en D2 output
	DDRB |= (1<<PB7) | (1<<PB6);

	// Active low, D1 en D2 branden nu
}

static int button_S2_pressed(void)
{
	return ((PINF & (1<<PF2)) == 0);
}

int main(void)
{
	init();

	while (1)
	{
		if (button_S2_pressed())
		{
			PORTB |= (1<<PB6);
		}
	}
}
