#include <avr/io.h>

// Led D1 = 13 = PB7
// Led D2 = 12 = PB6
// Led D3 = 11 = PB5
// Led D4 = 10 = PB4
// Knop S1 = A1 = PF1
// Knop S2 = A2 = PF2
// Knop S3 = A3 = PF3

static void init(void)
{
	// Led D1 en D3 output
	DDRB |= (1<<PB7) | (1<<PB5);

	// active low, D3 brandt nu, zet D1 uit
	PORTB &= ~(1<<PB7);
}

int main(void)
{
	init();

	while (1)
	{
		if ((PINF & (1<<PF1)) == 0)
		{
			PORTB &= ~(1<<PB5);
		}
		else
		{
			PORTB |= (1<<PB5);
		}
	}
}
