#include <avr/io.h>
#ifndef F_CPU
#define F_CPU 16000000
#endif
#include <util/delay.h>

// Led D1 = 13 = PB7
// Led D2 = 12 = PB6
// Led D3 = 11 = PB5
// Led D4 = 10 = PB4
// Knop S1 = A1 = PF1
// Knop S2 = A2 = PF2
// Knop S3 = A3 = PF3

static void init(void)
{
	// Led D1 en D4 output
	DDRB |= (1<<PB7) | (1<<PB4);

	// D1 brandt altijd (default), D4 staat uit
	PORTB |= (1<<PB4);
}

static int button_S2_pressed(void)
{
	return ((PINF & (1<<PF2)) == 0);
}

int main(void)
{
	init();

	int button_already_down = 0;

	while (1)
	{
		if (button_S2_pressed())
		{
			if (!button_already_down)
			{
				PORTB ^= (1<<PB4);

				// Button pressed, debounce
				_delay_ms(20);

				button_already_down = 1;
			}
		}
		else	// Button released
		{
			if (button_already_down)
			{
				button_already_down = 0;
				// debounce
				_delay_ms(20);
			}
		}
	}
}
