#include <avr/io.h>
#include <avr/interrupt.h>

// Led D1 = 13 = PB7
// Led D2 = 12 = PB6
// Led D3 = 11 = PB5
// Led D4 = 10 = PB4
// Knop S1 = A1 = PF1
// Knop S2 = A2 = PF2
// Knop S3 = A3 = PF3

// f = 3 Hz
// 16*10^6 / 3 = 5333333 cycles
// Using prescaler of 256: 5333333 / 256 = 20833
// Init TCNT to 2^16 - 20833 = 44703
#define TCNT_INIT 44703u
#define OC_INIT ((TCNT_INIT) + 6944u)

static void led_D1_on(void) { PORTB &= ~(1<<PB7); }
static void led_D1_off(void) { PORTB |= (1<<PB7); }
static void led_D1_toggle(void) { PORTB ^= (1<<PB7); }

ISR(TIMER1_COMPA_vect)
{
	led_D1_on();
}

ISR(TIMER1_OVF_vect)
{
	TCNT1 = TCNT_INIT;
	led_D1_off();
}

static void init_led(void)
{
	DDRB |= (1<<PB7);
	PORTB |= (1<<PB7);
}

static void init_timer1(void)
{
	TCCR1A = 0;
	TCCR1B = (1<<CS12) | (0<<CS11) | (0<<CS10);
	TCNT1 = TCNT_INIT;
	OCR1A = OC_INIT;
	TIMSK1 = (1<<OCIE1A) | (1<<TOIE1);
}

void init(void)
{
	init_led();
	init_timer1();
	sei();
}

int main(void)
{
	init();

	while (1)
	{
	}
}
