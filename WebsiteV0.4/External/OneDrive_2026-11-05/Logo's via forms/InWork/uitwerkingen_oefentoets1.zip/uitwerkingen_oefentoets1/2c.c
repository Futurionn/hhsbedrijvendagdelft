#include <avr/io.h>
#include <avr/interrupt.h>

// Led D1 = 13 = PB7
// Led D2 = 12 = PB6
// Led D3 = 11 = PB5
// Led D4 = 10 = PB4
// Knop S1 = A1 = PF1
// Knop S2 = A2 = PF2
// Knop S3 = A3 = PF3

// OC1A is verbnden met PB5. Dit is led D3

static void init_led(void)
{
	DDRB |= (1<<PB5);
}

static void init_timer1(void)
{
	// Use mode 14 (Fast PWM, TOP in ICR1
	TCCR1A = (1<<WGM11) | (0<<WGM10);
	TCCR1B = (1<<WGM13) | (1<<WGM12);

	// Led is active low, op compare match dus 1 maken: COM1A1 = 1, COM1A0 = 1
	TCCR1A |= (1<<COM1A1) | (1<<COM1A0);

	// Prescaler of 256
	TCCR1B |= (1<<CS12) | (0<<CS11) | (0<<CS10);

	// Top in ICR1: 16000000/256 = 62500
	ICR1 = 62500u;

	// 70% duty cycle
	OCR1A = 43750;
}

void init(void)
{
	init_led();
	init_timer1();
}

int main(void)
{
	init();

	while (1)
	{
	}
}
